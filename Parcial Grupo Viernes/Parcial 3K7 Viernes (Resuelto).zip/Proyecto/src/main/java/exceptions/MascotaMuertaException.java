package exceptions;

public class MascotaMuertaException extends RuntimeException {
    public MascotaMuertaException(String mensaje) {
        super(mensaje);
    }
}
